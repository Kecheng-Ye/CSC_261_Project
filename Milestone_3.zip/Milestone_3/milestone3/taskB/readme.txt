The source of data is the Kaggle dataset: https://www.kaggle.com/datasnaek/youtube-new?select=USvideos.csv

We adopted a modified subset of the dataset with selected features. 
